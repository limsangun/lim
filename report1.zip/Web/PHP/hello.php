<?
echo "Hello PHP world!!";
?>
